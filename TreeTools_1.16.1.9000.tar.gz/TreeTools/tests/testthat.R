library("testthat")
library("TreeTools", quietly = TRUE, warn.conflicts = FALSE)

suppressPackageStartupMessages(test_check("TreeTools"))
